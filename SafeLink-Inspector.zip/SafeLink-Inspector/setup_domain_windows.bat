@echo off
title Setup Custom Domain: safelinkinspecktor-gehu
echo ================================================================
echo  Configuring custom domain: http://safelinkinspecktor-gehu:5000
echo ================================================================

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] Please Right-Click this file and select "Run as administrator"
    echo     so Windows can map 127.0.0.1 to safelinkinspecktor-gehu.
    pause
    exit /b
)

findstr /I "safelinkinspecktor-gehu" %WINDIR%\System32\drivers\etc\hosts >nul
if %errorLevel% equ 0 (
    echo [OK] Domain "safelinkinspecktor-gehu" is already registered in your hosts file!
) else (
    echo.>> %WINDIR%\System32\drivers\etc\hosts
    echo 127.0.0.1    safelinkinspecktor-gehu>> %WINDIR%\System32\drivers\etc\hosts
    echo [SUCCESS] Mapped 127.0.0.1 to safelinkinspecktor-gehu!
)

echo.
echo You can now run "python app.py" and open:
echo 👉 http://safelinkinspecktor-gehu:5000
echo.
pause
