from flask import Flask, render_template, request
import urllib.parse
import ssl
import socket
import hashlib
import math
import string
import requests
from datetime import datetime

app = Flask(__name__)

# In-memory store for recent URL scans (keeps last 5 scans)
scan_history = []


# ==========================================================
# MODULE 1: URL, SSL SOCKET & HTTP SECURITY HEADERS ANALYZER
# ==========================================================
def analyze_url(target_url):
    results = {
        "url": target_url if target_url else "",
        "ip_address": "Unresolved",
        "https": False,
        "ssl_valid": False,
        "security_headers": {},
        "status": "Corrupted/Invalid",
        "details": [],
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    if not target_url:
        results["details"].append("No URL was provided.")
        return results

    target_url = target_url.strip()
    if not target_url.startswith(('http://', 'https://')):
        target_url = 'http://' + target_url
        results["url"] = target_url

    parsed_url = urllib.parse.urlparse(target_url)
    hostname = parsed_url.hostname

    if not hostname:
        results["details"].append("Invalid URL structure provided.")
        return results

    results["status"] = "Safe"

    # 1. DNS & IPv4 Resolution
    try:
        ip_addr = socket.gethostbyname(hostname)
        results["ip_address"] = ip_addr
        results["details"].append(f"Resolved Host IP: {ip_addr}")
    except Exception:
        results["status"] = "Suspicious"
        results["details"].append("DNS Resolution failed: Domain does not resolve to an active IP.")

    # 2. Check HTTPS Transport Protocol
    if parsed_url.scheme == 'https':
        results["https"] = True
        results["details"].append("Uses encrypted HTTPS transport protocol.")
    else:
        results["status"] = "Suspicious"
        results["details"].append("Insecure HTTP protocol used (Missing transport encryption).")

    # 3. Check SSL Certificate via Socket (Port 443)
    if results["https"]:
        try:
            context = ssl.create_default_context()
            with socket.create_connection((hostname, 443), timeout=3) as sock:
                with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                    cert = ssock.getpeercert()
                    results["ssl_valid"] = True
                    exp_date = cert.get('notAfter', 'Unknown')
                    results["details"].append(f"SSL Certificate is valid (Expires: {exp_date}).")
        except Exception as e:
            results["status"] = "Suspicious"
            results["ssl_valid"] = False
            results["details"].append(f"SSL Certificate validation failed: {str(e)}")

    # 4. HTTP Defensive Security Headers Audit
    try:
        resp = requests.get(target_url, timeout=4, headers={'User-Agent': 'safelinkinspecktor-gehu/2.0'})
        headers_to_check = [
            'Strict-Transport-Security',
            'Content-Security-Policy',
            'X-Frame-Options',
            'X-Content-Type-Options'
        ]
        missing_headers = []
        for h in headers_to_check:
            if h in resp.headers:
                results["security_headers"][h] = "Present"
            else:
                results["security_headers"][h] = "Missing"
                missing_headers.append(h)

        if len(missing_headers) == len(headers_to_check):
            results["details"].append("Warning: All major HTTP defensive security headers are missing.")
        else:
            results["details"].append(f"Security Headers Checked ({4 - len(missing_headers)}/4 active).")
    except Exception:
        results["details"].append("Could not fetch HTTP response headers from target server.")

    # 5. Heuristic Phishing Keyword Detection
    suspicious_keywords = ['login', 'verify', 'update', 'banking', 'secure', 'account', 'free', 'signin', 'wallet']
    if any(keyword in target_url.lower() for keyword in suspicious_keywords):
        if not results["https"] or not results["ssl_valid"]:
            results["status"] = "Potentially Malicious"
            results["details"].append("High Risk: Sensitive phishing keywords combined with weak security.")
        else:
            results["details"].append("Advisory: URL contains sensitive verification keywords; verify domain authenticity.")

    # Save to recent scan history
    scan_history.insert(0, {
        "url": results["url"],
        "ip": results["ip_address"],
        "status": results["status"],
        "time": results["timestamp"]
    })
    if len(scan_history) > 5:
        scan_history.pop()

    return results


# ==========================================================
# MODULE 2: PASSWORD SECURITY, ENTROPY & HIBP BREACH AUDITOR
# ==========================================================
def inspect_password_security(password):
    length = len(password)
    has_upper = any(c.isupper() for c in password)
    has_lower = any(c.islower() for c in password)
    has_digit = any(c.isdigit() for c in password)
    has_special = any(c in string.punctuation for c in password)

    weak_sequences = ['1234', 'qwerty', 'password', 'admin', 'welcome', '1111', '0000']
    has_weak_pattern = any(seq in password.lower() for seq in weak_sequences)

    # Calculate character pool size & Shannon/Pool entropy: E = L * log2(Pool)
    pool_size = 0
    if has_lower: pool_size += 26
    if has_upper: pool_size += 26
    if has_digit: pool_size += 10
    if has_special: pool_size += 32

    entropy = round(length * math.log2(pool_size), 1) if pool_size > 0 else 0.0

    # Estimate offline GPU brute-force crack time (10 Billion guesses/sec)
    combinations = (pool_size ** length) if pool_size > 0 else 1
    seconds = combinations / 10_000_000_000
    if seconds < 1:
        crack_time = "Instant (< 1 second)"
    elif seconds < 60:
        crack_time = f"{int(seconds)} Seconds"
    elif seconds < 3600:
        crack_time = f"{int(seconds // 60)} Minutes"
    elif seconds < 86400:
        crack_time = f"{int(seconds // 3600)} Hours"
    elif seconds < 31536000:
        crack_time = f"{int(seconds // 86400)} Days"
    elif seconds < 31536000 * 1000:
        crack_time = f"{round(seconds / 31536000, 1)} Years"
    else:
        crack_time = "Centuries (Cryptographically Strong)"

    # Calculate Score out of 100
    score = 0
    if length >= 8: score += 20
    if length >= 12: score += 20
    if has_upper: score += 15
    if has_lower: score += 15
    if has_digit: score += 15
    if has_special: score += 15
    if has_weak_pattern: score = max(10, score - 35)

    checks = {
        "Minimum Length (>= 12 Characters)": "Passed" if length >= 12 else f"Failed ({length} chars)",
        "Uppercase Letters (A-Z)": "Passed" if has_upper else "Missing",
        "Lowercase Letters (a-z)": "Passed" if has_lower else "Missing",
        "Numeric Digits (0-9)": "Passed" if has_digit else "Missing",
        "Special Symbols (!@#$%^&*)": "Passed" if has_special else "Missing",
        "Pattern & Dictionary Check": "Failed (Weak Sequence)" if has_weak_pattern else "Passed"
    }

    recommendations = []
    if length < 12:
        recommendations.append("Increase password length to at least 12–16 characters to raise entropy above 80 bits.")
    if not (has_upper and has_lower and has_digit and has_special):
        recommendations.append("Mix uppercase, lowercase, numbers, and punctuation symbols to expand the character pool.")
    if has_weak_pattern:
        recommendations.append("Avoid predictable keyboard walks ('qwerty', '1234') or common dictionary words.")

    # HIBP k-Anonymity API Check (Only 5-char SHA-1 prefix leaves the machine)
    sha1_hash = hashlib.sha1(password.encode('utf-8')).hexdigest().upper()
    prefix, suffix = sha1_hash[:5], sha1_hash[5:]
    breach_count = 0
    api_error = None

    try:
        res = requests.get(
            f"https://api.pwnedpasswords.com/range/{prefix}",
            timeout=4,
            headers={'User-Agent': 'safelinkinspecktor-gehu-PasswordAuditor'}
        )
        if res.status_code == 200:
            for line in res.text.splitlines():
                h_suffix, count = line.split(':')
                if h_suffix == suffix:
                    breach_count = int(count)
                    break
        else:
            api_error = f"HIBP API Status {res.status_code}"
    except Exception as e:
        api_error = f"Offline Mode ({str(e)})"

    if breach_count > 0:
        score = min(score, 20)
        strength_label = "Compromised / Critical Risk"
        badge_class = "Potentially Malicious"
        recommendations.insert(0, f"CRITICAL: This password appeared {breach_count:,} times in public data breaches. Never use it!")
    else:
        if score >= 80:
            strength_label = f"Strong (Score: {score} / 100)"
            badge_class = "Safe"
        elif score >= 50:
            strength_label = f"Moderate (Score: {score} / 100)"
            badge_class = "Suspicious"
        else:
            strength_label = f"Weak (Score: {score} / 100)"
            badge_class = "Potentially Malicious"
        recommendations.append("Verified safe against 800M+ leaked HIBP credentials via zero-knowledge k-Anonymity.")

    return {
        "prefix": prefix,
        "length": length,
        "entropy": entropy,
        "crack_time": crack_time,
        "score": score,
        "strength_label": strength_label,
        "badge_class": badge_class,
        "checks": checks,
        "recommendations": recommendations,
        "count": breach_count,
        "error": api_error
    }


# ==========================================================
# MODULE 3: HIBP-STYLE GMAIL / EMAIL DATA BREACH SEARCH
# ==========================================================
def check_email_breaches(email):
    email = email.strip().lower()
    if '@' not in email or '.' not in email.split('@')[-1]:
        return {
            "email": email,
            "domain": "Invalid",
            "valid_domain": False,
            "status": "Corrupted/Invalid",
            "breach_count": 0,
            "breaches": [],
            "error": "Invalid email address format."
        }

    domain = email.split('@')[-1]
    valid_domain = False
    try:
        socket.gethostbyname(domain)
        valid_domain = True
    except Exception:
        valid_domain = False

    # Built-in Demo Profiles for guaranteed Viva / Offline demonstration
    demo_breaches = {
        "test@gmail.com": [
            {
                "name": "Canva (May 2019 Data Breach)",
                "scale": "137M Accounts Exposed",
                "description": "In May 2019, the graphic design site Canva suffered a data breach exposing customer account records.",
                "data_classes": "Email addresses, Names, Usernames, Bcrypt Password Hashes",
                "remediation": "Rotate your Canva password and revoke old OAuth tokens."
            },
            {
                "name": "BigBasket (October 2020 Data Breach)",
                "scale": "20M Accounts Exposed",
                "description": "In October 2020, Indian grocery platform BigBasket suffered a database leak sold on dark web forums.",
                "data_classes": "Email addresses, Phone numbers, Physical addresses, SHA-1 Password Hashes",
                "remediation": "Change reused passwords and enable 2-Factor Authentication (2FA) on Gmail."
            }
        ],
        "breached@gmail.com": [
            {
                "name": "Adobe (October 2013 Data Breach)",
                "scale": "153M Accounts Exposed",
                "description": "In October 2013, 153 million Adobe accounts were breached with encrypted password hints and customer emails.",
                "data_classes": "Email addresses, Password hints, Passwords, Usernames",
                "remediation": "Update your Adobe credentials and avoid reusing passwords across services."
            }
        ]
    }

    if email in demo_breaches:
        breaches = demo_breaches[email]
        return {
            "email": email,
            "domain": domain,
            "valid_domain": valid_domain,
            "status": "Potentially Malicious",
            "breach_count": len(breaches),
            "breaches": breaches,
            "error": None
        }

    # Live Free API Check (XposedOrNot free breach intelligence API)
    breaches_found = []
    try:
        url = f"https://api.xposedornot.com/v1/check-email/{urllib.parse.quote(email)}"
        res = requests.get(url, timeout=4, headers={'User-Agent': 'safelinkinspecktor-gehu-HIBP'})
        if res.status_code == 200:
            data = res.json()
            raw_list = data.get("breaches", [[]])[0]
            for b_name in raw_list[:5]:
                breaches_found.append({
                    "name": f"{b_name} Data Breach",
                    "scale": "Verified Public Leak",
                    "description": f"This email address was identified in the publicly indexed {b_name} security breach.",
                    "data_classes": "Email addresses, Account Credentials",
                    "remediation": f"Change your {b_name} password immediately and enable 2FA."
                })
    except Exception:
        pass

    status = "Potentially Malicious" if len(breaches_found) > 0 else "Safe"
    return {
        "email": email,
        "domain": domain,
        "valid_domain": valid_domain,
        "status": status,
        "breach_count": len(breaches_found),
        "breaches": breaches_found,
        "error": None
    }


# ==========================================================
# FLASK ROUTES
# ==========================================================
@app.route('/')
def home():
    return render_template('index.html', history=scan_history)

@app.route('/scan', methods=['POST'])
def scan():
    url_to_scan = request.form.get('urlInput')
    analysis_results = analyze_url(url_to_scan)
    return render_template('results.html', data=analysis_results)

@app.route('/hibp-check', methods=['POST'])
def hibp_check():
    password_input = request.form.get('passwordInput', '')
    result = inspect_password_security(password_input)
    return render_template('hibp_results.html', result=result)

@app.route('/email-breach-check', methods=['POST'])
def email_breach_check():
    email_input = request.form.get('emailInput', '')
    report = check_email_breaches(email_input)
    return render_template('email_breach_results.html', report=report)


if __name__ == '__main__':
    print("\n" + "="*62)
    print(" 🛡️  SAFELINK INSPECTOR v2.0 (GEHU SOC SUITE) IS LIVE!")
    print(" 🌐 Custom URL  : http://safelinkinspecktor-gehu:5000")
    print(" 🔗 Local URL   : http://127.0.0.1:5000")
    print("="*62 + "\n")
    # Listening on 0.0.0.0 so both 127.0.0.1 and custom hostname 'safelinkinspecktor-gehu' work
    app.run(host='0.0.0.0', port=5000, debug=True)
