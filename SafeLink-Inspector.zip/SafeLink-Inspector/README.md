# SafeLink Inspector v2.0 (safelinkinspecktor-gehu)

Developed by: **Aman Bisht** (BCA Cyber Security, Graphic Era Hill University)

## How to Open Your App Using `http://safelinkinspecktor-gehu:5000` (Instead of IP `127.0.0.1`)

### Step 1: Map the Custom Hostname (One-Time Setup)
- **On Windows:** Right-click **`setup_domain_windows.bat`** inside this folder and select **Run as administrator**. It automatically adds `127.0.0.1 safelinkinspecktor-gehu` to your Windows `hosts` file.
- **On Linux / Mac:** Run `bash setup_domain_linux.sh` in your terminal.

### Step 2: Run the Flask Server in VS Code
1. Open the `SafeLink-Inspector` folder in VS Code.
2. Open the terminal (`Ctrl + ~`) and install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Start the server:
   ```bash
   python app.py
   ```
4. Open your browser and visit:
   👉 **http://safelinkinspecktor-gehu:5000**
