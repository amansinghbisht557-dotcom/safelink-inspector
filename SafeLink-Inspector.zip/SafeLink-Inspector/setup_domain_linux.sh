#!/bin/bash
echo "================================================================"
echo " Configuring custom domain: http://safelinkinspecktor-gehu:5000"
echo "================================================================"

if grep -qi "safelinkinspecktor-gehu" /etc/hosts; then
    echo "[OK] Domain 'safelinkinspecktor-gehu' is already in /etc/hosts!"
else
    echo "127.0.0.1    safelinkinspecktor-gehu" | sudo tee -a /etc/hosts > /dev/null
    echo "[SUCCESS] Mapped 127.0.0.1 to safelinkinspecktor-gehu!"
fi

echo ""
echo "You can now run 'python3 app.py' and open:"
echo "👉 http://safelinkinspecktor-gehu:5000"
